public class divisionTester {

    public static void main(String[] args) {

        System.out.print("0.005 / 5 = ");
        double divide = 0.005 / 5;
        System.out.print(divide);

    }
}
